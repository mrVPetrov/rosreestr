package rosreestr;

/**
 * Created by Vadim on 09.04.2017.
 */

/**
 * Права и ограничения
 */
public class Rights_n_Restrictions {
	String rights;
	String restrictions;
}
