/**
 * Created by Vadim on 09.04.2017.
 */
public enum Parse_Type {
	API, SITE
}
